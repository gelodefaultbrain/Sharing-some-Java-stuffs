/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InputOutFile;
import java.io.File;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Gels
 */
public class FileIO {
    
    public static void main(String[] args){
       // throws IOException , FileNotFoundException    it works!!
        // Make a file and Print something
        File file = new File("Myfile.txt");
        
        try{
         PrintWriter output = new PrintWriter(file);
         output.println("My first File handling in Java");
         output.println("January 15, 2017");
         output.close();
        } catch(IOException e){
            System.out.println("Error can't find File");
        }
        // Read from a file
        try{
          Scanner input = new Scanner(file);   
          String text = input.nextLine();
          String date = input.nextLine();
          
          System.out.printf("Read from the File:\n %s  \n%s\n",text,date);
        }catch(FileNotFoundException e){
            System.out.printf("Error %s:",e);
        }
    }
}
