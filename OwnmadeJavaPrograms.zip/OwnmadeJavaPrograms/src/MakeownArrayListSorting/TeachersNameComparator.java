/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MakeownArrayListSorting;
import java.util.Comparator;
/**
 *
 * @author Gels
 */
public class TeachersNameComparator implements Comparator<Teachers> {
     
    @Override
      public int compare(Teachers n1, Teachers n2){
          
          return n1.Tname().compareToIgnoreCase(n2.Tname());
      }
}
