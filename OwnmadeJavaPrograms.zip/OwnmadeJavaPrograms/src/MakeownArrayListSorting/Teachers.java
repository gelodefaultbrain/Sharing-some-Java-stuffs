/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MakeownArrayListSorting;

/**
 *
 * @author Gels
 */
public class Teachers {
    
    private int rate;
    private String _name;
    
    public Teachers(String name , int rating){
        this._name = name;
        this.rate = rating;
    }
    public int Rate(){
     return this.rate;
    }
    
    public String Tname(){
        return this._name;   
    }
}
