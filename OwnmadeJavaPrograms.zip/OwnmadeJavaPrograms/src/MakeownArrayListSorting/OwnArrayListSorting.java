/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MakeownArrayListSorting;
import java.util.ArrayList;
import java.util.Collections;
/**
 *
 * @author Gels
 */
public class OwnArrayListSorting {
     public static void main(String[] args){
         ArrayList<Teachers> set = new ArrayList<>();
         
         set.add(new Teachers("Naz",5));
         set.add(new Teachers("Pancho", 3));
         set.add(new Teachers("Borromeo",2));
         set.add(new Teachers("Lucilo",1));
         set.add(new Teachers("Noli",2));
         System.out.println("Unsorted");
         for(Teachers stupid: set)
         {
           System.out.printf("Teacher %s Rating %d\n",stupid.Tname(),stupid.Rate());
         }
         Collections.sort(set, new TeachersNameComparator());
         System.out.println();
         System.out.println("Sorted by Name");
         Print(set);
         Collections.sort(set, new RateComparator());
         System.out.println("Sorted by Rate");
         Print(set);
         }
     public static void Print(ArrayList<Teachers> a1){
          
         for(Teachers stupid : a1)
         {
             System.out.printf("Name: %s Rating %d\n",stupid.Tname(),stupid.Rate());
         }
     }
}
