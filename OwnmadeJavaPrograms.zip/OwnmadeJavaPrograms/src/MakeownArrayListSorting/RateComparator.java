/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MakeownArrayListSorting;
import java.util.Comparator;
/**
 *
 * @author Gels
 */
public class RateComparator implements Comparator<Teachers>{
    
    @Override
      public int compare(Teachers r1, Teachers r2){
          return r1.Rate()-r2.Rate();
      }
}
