/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ownmadejavaprograms;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class AgeMainMethod {
    
    
      public static void main(String[] args){
             
              Age myAge = new Age();
              myAge.getAge();
        }
}
