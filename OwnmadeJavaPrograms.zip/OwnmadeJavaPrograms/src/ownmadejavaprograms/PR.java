/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ownmadejavaprograms;
/**
 *
 * @author LENOVO
 */
public class PR {
    
      public static void main(String[] args){
          

        double Money = 178.75;
       
        
        System.out.println();
        System.out.println("Output");
        System.out.println("The coin breakdown for "+Money + " is ");
        int OneHundred = (int) Money / 100;
        System.out.println();
        System.out.print("One Hundred peso bills:\t" + " " + OneHundred);
        System.out.println();
        
        int Fifty = (int) ((Money % 100) / 50);
        System.out.print("Fifty peso bills:\t" + " "+Fifty);
        System.out.println();
        
        int TwentyPeso = (int) ((Money % 50) / 20);
        System.out.print("Twenty peso bills:\t" + " " + TwentyPeso);
        System.out.println();
        
        int TenPeso = (int) ((Money % 10) / 10);
        System.out.print("Ten peso coin:\t" + " " +TenPeso);
        System.out.println();
        
        int FivePeso = (int) ((Money  % 10) / 5);
        System.out.print("Five peso coin:\t" + " " +FivePeso);
        System.out.println();
        
        int OnePeso = (int) ((Money % 5) / 1);
        System.out.print("One peso coin:\t" + " " +OnePeso);
        System.out.println();
        
        int TwentyFiveCents = (int) ((Money % (int) (Money)) / 0.25);
        System.out.print("Twenty five cents coin:\t" + " "+TwentyFiveCents);
        System.out.println();   
      }
}
