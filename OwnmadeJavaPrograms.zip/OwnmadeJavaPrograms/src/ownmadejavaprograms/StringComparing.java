/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ownmadejavaprograms;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
public class StringComparing {
    
       public static void main(String[] args){
           
          Scanner input = new Scanner(System.in);
          
          System.out.println("Enter two Strings");
          String name1 = input.nextLine();
          String name2 = input.nextLine();
          
          if(name1.compareTo(name2)  == 0)
          {
             System.out.println("They are the same");
          } else
          {
            System.out.println("They are not the same");  
          }
       }
      
}
