/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ownmadejavaprograms;
import java.util.Random;
/**
 *
 * @author Gels
 */
public class Answer {
    private double ans; 
    private double remainder;
    private Random generator;
    public Answer(int a,int b){
     this.ans = Math.sqrt(a);
     this.remainder = 100 / b;
     generator = new Random();
    }
    public double getans(){
      return this.ans;
    }
    public double getR(){
      return this.remainder;   
    }
    public int Gen(){
     return generator.nextInt(10);
    }
}
