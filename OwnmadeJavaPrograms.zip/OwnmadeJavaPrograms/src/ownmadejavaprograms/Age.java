/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ownmadejavaprograms;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Age {
    
             public void getAge(){
           
               Scanner input = new Scanner(System.in);
               System.out.println("Enter yout Age ins years");
               System.out.print("Age: ");
               int Years = input.nextInt();
               
               long days = Years * 365;
               long hours = Years * (24 * 365);
               long mins =  Years * (60 * 24 * 365);
               long seconds = Years * ((3600 * 24 * 365));
               long milli = Years  * (60000 * 60 * 24 * 365);
               
               System.out.println("Your age in Days is " +days);
               System.out.println("Your age in Hours is " +hours);
               System.out.println("Your age in Minutes is " +mins);
               System.out.println("Your age in seconds is " +seconds);
               System.out.println("Your age in MilliSeconds is " +milli);   
       }
}
