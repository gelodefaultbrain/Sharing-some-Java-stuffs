/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ownmadejavaprograms;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Currency {
    
      public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your value: ");
        double value = input.nextDouble();
        
        System.out.println();
        System.out.println("Output");
        System.out.printf("The coin breakdown for %.2f pesos is\n",value);
        int OneHundred = (int) value / 100;
        System.out.println();
        System.out.print("One Hundred peso bills:\t");
        System.out.println(OneHundred);
        
        int Fifty = (int) ((value % 100) / 50);
        System.out.print("Fifty peso bills:\t");
        System.out.println(Fifty);
        
        int TwentyPeso = (int) ((value % 50) / 20);
        System.out.print("Twenty peso bills:\t");
        System.out.println(TwentyPeso);
        
        int TenPeso = (int) ((value % 10) /10);
        System.out.print("Ten peso coin:\t");
        System.out.println(TenPeso);
        
        int FivePeso = (int) ((value  % 10) / 5);
        System.out.print("Five peso coin:\t");
        System.out.println(FivePeso);
        
        int OnePeso = (int) ((value % 5) / 1);
        System.out.print("One peso coin:\t");
        System.out.println(OnePeso);
        
        int TwentyFiveCents = (int) ((value % (int) (value)) / 0.25);
        System.out.print("Twenty five cents coin:\t");
        System.out.println(TwentyFiveCents);
    }
}
