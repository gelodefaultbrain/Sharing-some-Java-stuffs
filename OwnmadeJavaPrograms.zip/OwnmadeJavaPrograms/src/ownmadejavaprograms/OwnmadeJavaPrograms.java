/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ownmadejavaprograms;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author Gels
 */
public class OwnmadeJavaPrograms {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("How many numbers you want?");
        System.out.println("Numbers: ");
        int elem = input.nextInt();
        int[] numbs = new int[elem];
        System.out.println("Please Enter your Specific Number");
        System.out.println("Number: ");
        for(int i=0; i < elem; i++)
        {
          System.out.printf("[%d]: ",i);
          numbs[i] = input.nextInt();
          Answer asd = new Answer(numbs[i],numbs[i]);
          System.out.println();
          System.out.printf("Sqrt %.0f Remainder %.0f Random %d\n",asd.getans(),asd.getR(),asd.Gen());
        }
        
    }
    
}
