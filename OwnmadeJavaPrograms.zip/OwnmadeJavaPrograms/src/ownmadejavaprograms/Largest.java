/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ownmadejavaprograms;

/**
 *
 * @author LENOVO
 */
import java.util.*;
public class Largest {
    
    
       public static void main(String[] args){
        
          Scanner input = new Scanner(System.in);
           System.out.println("Enter how many numbers");
           int x = input.nextInt();
          
           int[] array = new int[50];
           int largest = array[0];
          System.out.println("Enter your numbers"); 
           for(int i = 0; i < x; i++)
           {
               array[i] = input.nextInt();
               if(array[i] > largest)
               {
                  largest = array[i];   
               }
           }
           System.out.println("Largest number is "+largest);
         }
   }
