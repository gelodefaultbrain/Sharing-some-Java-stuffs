/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hardware;

/**
 *
 * @author LENOVO
 */
import java.util.*;
public class HardwareItems {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        String[] items = new String[3];
        String item;
        String UPC = "999";
        double[] price = new double[3];
        int counter = 0;
        double total = 0.0;
        System.out.println("This order-processing program simulates using a code reader to scan an item and creates an invoice");
        do{
           if(counter != 0)
           {
            System.out.println("Please scan the name of the next item: ");   
           }else
           {
           System.out.println("Please scan the name of the first item: ");
           }
           item = input.nextLine();
           if(item.equals("hammer"))
           {
             System.out.println("Price of Hammer: $9.95");
             items[counter] = item;
             price[counter] = 9.95;  
           }else if(item.equals("saw"))
           {
             System.out.println("Price of Saw: $20.15");  
             items[counter] = item;
             price[counter] = 20.15;
           }else if(item.equals("shovel"))
           {
             System.out.println("Priceof Shovel: $35.40");  
             items[counter] = item;
             price[counter] = 35.40;  
           }else if(item.equals(UPC))
           {
              System.out.println(" "+counter + " items scanned.");
              System.out.print("Product Name\t");
              System.out.println("Price ");
              for(int i = 0; i < price.length; i++)
              {
                  System.out.println(items[i]+"\t\t"+ price[i]);
                  total = total + price[i];
              }
              System.out.printf("Total\t\t%.2f\n",total);
           }else
           {
             System.out.println("Item not found!");   
             continue;
           }
           counter++;
        }while(!item.equals(UPC));
    }
    
}
