/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JFrameFromScratch;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author LENOVO
 */
public class JFrameFromScratch {
     public static final int width = 500;
     public static final int height = 500;
    
    public static void main(String[] args){
     JButton button = new JButton("Here");  
     JFrame mywindow = new JFrame("Title");
     mywindow.setSize(width, height);
     JLabel mylabel = new JLabel("Dont click");
     
     //Pwede man dgd basta hangga't pwede think of it like it's sequencial
     //mywindow.getContentPane().add(button);
     //mywindow.getContentPane().add(mylabel); // tig add so myLabel
     
    mywindow.getContentPane().add(button);
    mywindow.getContentPane().add(mylabel); // tig add so myLabel
     button.setSize(200, 20); // (width,height)
     button.setLocation(50, 50);
   // WindowDestroyer myListener = new WindowDestroyer();
    //mywindow.addWindowListener(myListener);
     
     mywindow.setVisible(true);
}
}
