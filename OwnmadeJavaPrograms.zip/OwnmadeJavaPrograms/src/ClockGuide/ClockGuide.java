/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClockGuide;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author LENOVO
 */
public class ClockGuide {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Calendar timer = Calendar.getInstance();
        timer.getTime();
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
        String time1 = df.format(timer.getTime());
        SimpleDateFormat df1 = new SimpleDateFormat("dd-y-MM");
        String time2 = df1.format(timer.getTime());
        
        System.out.println(time1);
        System.out.println(time2);
    }
    
}
