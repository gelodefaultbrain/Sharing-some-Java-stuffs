/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pogi;
import java.util.Comparator;
/**
 *
 * @author Gels
 */
public class PogiComparator implements Comparator<String> {
    
    @Override
    public int compare(String name1, String name2){
        return name1.compareToIgnoreCase(name2);
    }
}
