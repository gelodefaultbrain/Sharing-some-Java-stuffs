/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pogi;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
/**
 *
 * @author Gels
 */
public class PogiSort {
    public static void main(String[] args){
         
        ArrayList<String> gwapo = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter how many names:");
        int elem = input.nextInt();
        String str;
        System.out.println("Enter names:");
        for(int i =0; i <elem; i++)
        {
            str = input.next();
            gwapo.add(str);
        }
        System.out.println("Unsorted");
        Print(gwapo);
        Collections.sort(gwapo,new PogiComparator());
        System.out.println("Sorted");
        Print(gwapo);
        Collections.binarySearch(gwapo,"Gels",new PogiComparator());
        System.out.printf("The %s was found\n","Gels");
    }
    public static void Print(ArrayList<String> tmp){
      for(String psy: tmp)
      {
          System.out.printf("Gwapo: %s\n",psy);
      }
    }
}
