/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TimerPackage;

/**
 *
 * @author LENOVO
 */
public class Timer {
    
       public static void main(String[] args){
       
        long lastTime = System.nanoTime();
        boolean running = true;
        int timer = 0;
        long now ;
       int i = 0;
        while(running)   
        {
            now = System.nanoTime();
            timer += (now - lastTime);
            lastTime = now;
            
            if(timer >= 1000000000)// kaya sya greater than ta ibig sabihon if nag equal or excede
                // sa 1000000000  or 1billion it means 1 second nag past in nano seconds so it means
                // ma count na and rest of the process
            {
             i++;
              timer = 0; // back to zero ta ngani sa sunod ma check if nag >= 1B that it means another
                      // 1 second
              System.out.println(i);
            }
        }
        
       }
       
}
