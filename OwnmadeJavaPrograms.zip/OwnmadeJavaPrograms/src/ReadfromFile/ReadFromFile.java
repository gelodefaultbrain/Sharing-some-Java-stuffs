/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ReadfromFile;
import java.io.File;
import java.util.Scanner;;
import java.io.FileNotFoundException;
/**
 *
 * @author Gels
 */
public class ReadFromFile {
    public static void main(String[] args){
      Scanner input = new Scanner(System.in);
      File _file;
      String file;
      System.out.println("Enter the name of File");
      file = input.nextLine();
      try{
      _file = new File(file);
      }catch(Exception e){
        System.out.printf("Error   File does not Exist");   
      }
      try{
      Scanner inp = new Scanner(file);
      String name = inp.nextLine();
      int age = inp.nextInt();
      String course = inp.nextLine();
      String date = inp.nextLine();
      for(int i = 0; i < file.length(); i++)
      {
          System.out.printf("%s\n%d\n%s\n%s\n",name,age,course,date);
      }
      } catch(Exception e){
          System.out.printf("Where is file\n");
      }
    }
}
