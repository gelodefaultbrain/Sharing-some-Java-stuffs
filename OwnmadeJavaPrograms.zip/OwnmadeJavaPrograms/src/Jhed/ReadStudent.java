/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jhed;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
public class ReadStudent {
    
    public void studentsList(){
    String [] names = new String[5];
     Scanner sc = new Scanner(System.in);
     System.out.println("Please enter student's name: ");
     for (int i = 0; i < names.length; i++){
        System.out.print("Student "+(i+1) + ": ");
        names[i] = sc.nextLine();     
        }
        System.out.println();
        
        System.out.println("Students are: ");
       for (String i : names) {
       System.out.println(i);
        }
       System.out.println();
}
}
