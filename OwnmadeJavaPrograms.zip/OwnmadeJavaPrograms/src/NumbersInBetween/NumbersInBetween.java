package NumbersInBetween;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
import java.util.*;
public class NumbersInBetween {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Enter your two numbers to look for the Numbers in between: ");
        Scanner input = new Scanner(System.in);
        System.out.print("First number: ");
        int firstNumber = input.nextInt();
        System.out.print("Second number: ");
        int secondNumber = input.nextInt();
        
        System.out.println();
        if(firstNumber - secondNumber == 1 || firstNumber - secondNumber == -1)
        {
          System.out.println("There are no numbers in between");   
        }else if(firstNumber < secondNumber)
         {
          System.out.println("Numbers in between are: ");
          for(int i = firstNumber + 1; i < secondNumber; i++)   
          {
            System.out.print(i + " ");   
          }
          System.out.println();
        }else if(firstNumber > secondNumber)
        {
         System.out.println("Numbers in between are: ");
         for(int i = firstNumber - 1; i > secondNumber; i--)   
         {
             System.out.print(i + " ");   
         }
         System.out.println();
        }else
        {
          System.out.println("Entered two numbers dont have numbers in between");
        }
    }
    
}
