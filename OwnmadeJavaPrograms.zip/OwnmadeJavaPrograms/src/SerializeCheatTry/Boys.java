/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SerializeCheatTry;
import java.io.Serializable;
/**
 *
 * @author Gels
 */
public class Boys implements Serializable{
    private String _name;
    private int _age;
    public Boys(String name, int age){
        this._name = name;
        this._age = age;
    }
    
    public String getN(){
      return this._name;
    }
    public int getAge(){
     return this._age;  
        }
}




