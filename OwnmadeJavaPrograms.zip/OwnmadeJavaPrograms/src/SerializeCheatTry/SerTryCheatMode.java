/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SerializeCheatTry;
// or import jaba.io.*;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
/**
 *
 * @author Gels
 */
public class SerTryCheatMode {
    public static void main(String[] args) throws IOException, ClassNotFoundException {    
         
      File file = new File("Boys.txt");
      ArrayList<Boys> boys = new ArrayList<>();
       
      boys.add(new Boys("Louise",18));
      boys.add(new Boys("Christian",18));
      boys.add(new Boys("Angelica",42));
      boys.add(new Boys("Binay",45));
        
      try{
        FileOutputStream fo = new FileOutputStream(file); // this will write to the file but treats as Bytes
        ObjectOutputStream output = new ObjectOutputStream(fo); 
        for(Boys b : boys)
        {
          output.writeObject(b);
        }
        fo.close();
        output.close();
          }catch(IOException ex){
              
          }
       
        FileInputStream fi = new FileInputStream(file);
        ObjectInputStream input = new ObjectInputStream(fi);
        
        ArrayList<Boys> boys2 = new ArrayList<>();
        try{
        while(true)
        {
         Boys t = (Boys)input.readObject();  
         boys2.add(t);
        }
        }catch(EOFException ex){
          
        }
     for(Boys s: boys2)
     {
       System.out.printf("%s\n",s);  
     }
}
}



