/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fibonacci;

/**
 *
 * @author LENOVO
 */
public class FibonacciExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int firstNumber = 0 , secondNumber = 1 , nextNumber;
        final int COUNT_LIMIT = 10;
        
        System.out.print(" " + firstNumber);
        System.out.print(" " + secondNumber);
        nextNumber = firstNumber + secondNumber;
        
        while(nextNumber <= COUNT_LIMIT)
        {
          System.out.print(" " + nextNumber);
          firstNumber = secondNumber;
          secondNumber = nextNumber;
          nextNumber = firstNumber + secondNumber;
        }
        System.out.println();
    }
    
}
