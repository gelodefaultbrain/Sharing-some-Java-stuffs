/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package File;
import java.io.File;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
/**
 *
 * @author Gels
 */
public class InputInaFile {
     public static void main(String[] args){
       File file = new File("Names.txt");  
       int elem;
       String name;
       System.out.println("Enter how many names:");
       Scanner input = new Scanner(System.in);
       elem = input.nextInt();
       System.out.println("Enter names:");
       try {
       PrintWriter output = new PrintWriter(file);
       for(int i=0; i< elem; i++)
       {
         name = input.next();
         output.println(name);
       }
       output.close();
       } catch(IOException ex){     
          System.out.println("FIle not found");
          } 
     try {
     Scanner inp = new Scanner(file);
     System.out.println("Read from file:");
     for(int i=0; i <elem; i++)
     {
      name = inp.nextLine();
      System.out.printf("%s\n",name);
     }
     } catch(FileNotFoundException ex){
         System.out.println("Where is file?");
     }
}
}




