/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TrytryPackage;

/**
 *
 * @author LENOVO
 */
public class PythonProv{
        
        private int sample;
        int r = 2;
        public PythonProv(int s){
            this.sample = s;
            int x = 20;
        }
        
        public void justPrint(){
           System.out.println(this.sample);
        }
        
        public void method1(){
            //System.out.println(this.x);//#WRONG
        }
        
    }