/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TrytryPackage;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
public class ReadStudent {
    
    
    String[] students;
    
     public void studentList(){
         Scanner input = new Scanner(System.in);
         students  = new String[5];
         System.out.println("Enter the name of Students:");
         for(int i = 0; i < students.length; i++)
         {
              System.out.print("Student "+(i+1) + ": ");
              students[i] = input.nextLine();
         }
         System.out.println();
         System.out.println("The students are: ");
         for(int i = 0; i < students.length; i++)
         {
              System.out.println(students[i]);
         }
         System.out.println();
     }
}
