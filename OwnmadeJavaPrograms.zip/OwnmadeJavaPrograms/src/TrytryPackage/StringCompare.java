/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TrytryPackage;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class StringCompare {
    
    
       public static void main(String[] args){
    Scanner sc = new Scanner (System.in);
    String word1,word2;
    System.out.println("Enter two Strings: ");
    word1=sc.next();
    word2=sc.next();

    if (word1.equals(word2))
        System.out.println("They are the same");
    else
        System.out.println("They are not the same");
}

}
